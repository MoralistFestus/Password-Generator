<h1>Password Generator</h1>
<br>
<p>This project ilimade in Vue.Js JavaScript Library. A Strong password generator that generates passwords randomly, figure out password strengths etc</p>

<h3>Features Are:</h3>
<ul>
<li>Check password Strength</li>
<li>Generate Passwords Randomly</li>
<li>Choose Password Options</li>
<li>Lenght, Digit and Symbol</li>
<li>Copy Password to Clipboard</li>
</ul>

<p>Give this Project a Star and follow me up on twitter</p>

<p><a href="https://www.twitter.com/moralistfestus">@moralistfestus</a> on Twitter.</p>